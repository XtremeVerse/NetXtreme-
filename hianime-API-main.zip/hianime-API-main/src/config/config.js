const config = {
  baseurl: 'https://hianime.bz',
  baseurl_v2: 'https://kaido.to',
  providers: 'https://megacloud.club',

  headers: {
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0',
  },
};
export default config;
